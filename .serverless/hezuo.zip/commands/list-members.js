
// ***********
// list-teams
// ***********

exports.handler = (event, context, callback) => {
    const response = 'hezuo members: davidiog;alexgigs;supertony';
    callback(null, response);
};